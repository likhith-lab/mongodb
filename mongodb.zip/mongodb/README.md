first extract the file

then do to the file directory in command promt install npm files
        command: npm install
create .env file and 
    initialize SECRETE=  to a random variable
go to urls.json and give your mongodb url to it

four routes api/signup
                insert data into database
            api/signin
                logs in the user by findint the data
            api/update?password=""
                updates the user password
            api/delete
                deletes the user