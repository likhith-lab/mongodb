const mongoose=require("mongoose")
const urls=require("../urls.json")
mongoose.connect(urls["db-url"]).then(()=>{
    console.log("connected")
})

userSchema=mongoose.Schema({
    email:{
        type:String,
        required:true,
        unique:true
    },
    password:{
        type:String,
        required:true,
        minlength:8,
    }
})

const User=mongoose.model("User",userSchema)

module.exports=User