const express=require("express")
const app=express()
const userRoute=require("./routes/userRoutes.js")
app.use("/api",userRoute)
app.listen(3000,()=>{
    console.log("listening to port 3000")
})