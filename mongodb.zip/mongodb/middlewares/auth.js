const jwt=require("jsonwebtoken")
require("dotenv").config()
const auth=(req,res,next)=>{
    try{
        if(jwt.verify(req.headers.token,process.env.SECRET)){
            next()
        }
    }
    catch(err){
        res.status(401).json({
            message:"invalid token"
        })
    }
}
module.exports={auth}