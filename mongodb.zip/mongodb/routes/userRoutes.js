const express=require("express")
const app=express.Router()
const jwt=require("jsonwebtoken")
const {auth}=require("../middlewares/auth.js")
const User=require("../databases/db.js")
require("dotenv").config()
app.use(express.json())

app.post("/signup",async (req,res)=>{
    try{
        const success=new User(req.body)
        await success.save()
        if(success){
            const auth=jwt.sign({id:(success._id.toString())},process.env.SECRET)
            res.status(200).json({
                "token":auth,
                message:"user created successful"
            })
        }else{
            res.status(400).json({
                message:"invalid details"
            })
        }
        
    }catch(err){
        res.status(500).json({message:err.message})
    }
    
})

app.post("/signin",auth,async (req,res)=>{
    user=jwt.decode(req.headers.token,process.env.SECRET)
    success=await User.findOne({_id:user.id})
    if(success){
        console.log(success)
        res.status(200).json({
            message:"login successful"
        })
    }
    else{
        res.status(401).json({
            message:"user not found"
        })
    }
    
})
app.post("/update",auth,async (req,res)=>{
    user=jwt.decode(req.headers.token,process.env.SECRET)
    const updatePassword=req.query.password
    console.log(updatePassword)
    success=await User.findOneAndUpdate({_id:user.id},{password:updatePassword})
    if(success){
        const auth=jwt.sign({email:success.email,password:updatePassword},process.env.SECRET)
        console.log(success)
        res.status(200).json({
            message:"updated successful",
            token:auth
        })
    }
    else{
        res.status(401).json({
            message:"user not found"
        })
    }
    
})
app.post("/delete",auth,async (req,res)=>{
    user=jwt.decode(req.headers.token,process.env.SECRET)
    success=await User.findOneAndDelete({_id:user.id})
    if(success){
        console.log(success)
        res.status(200).json({
            message:"deleted successful"
        })
    }
    else{
        res.status(401).json({
            message:"user not found"
        })
    }
    
})

module.exports=app